<?php

class Order
{
    private $db;

    public function __construct()
    {
        $this->db = new Db();
        $this->db = $this->db->connect();
    }

    // Select the order
    public function createOrder($user_name, $user_email, $my_array)
    {
      $stmt = $this->db->prepare('INSERT INTO orders (customer_name, customer_email)
      VALUES (:customer_name, :customer_email);');

      $stmt->execute([
          ':customer_name' => $user_name,
          ':customer_email' => $user_email
      ]);

      $id_order = $this->db->lastInsertId();

      foreach($my_array as $key => $value)
      {
        $stmt = $this->db->prepare('INSERT INTO orders_items (order_id, ticket_id, used)
        VALUES (:order_id, :ticket_id, \'no\');');

        $stmt->execute([
          ':order_id' => $id_order,
          ':ticket_id' => $value
        ]);
        }
        header ("Location:confirm_order.php");
    }

    // Select the order
    public function selectOrder($id)
    {
        $stmt = $this->db->prepare('SELECT o.id, oi.id, t.name, o.customer_name, oi.used FROM orders_items oi
        JOIN orders o ON o.id = oi.order_id
        JOIN tickets t ON t.id = oi.ticket_id
        WHERE o.id = :id');

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    public function selectOrderStatus($id_item)
    {
        $stmt = $this->db->prepare('SELECT oi.used FROM orders_items oi
        JOIN orders o ON o.id = oi.order_id
        JOIN tickets t ON t.id = oi.ticket_id
        WHERE oi.id = :id');

        $stmt->bindParam(':id', $id_item, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetchColumn();
        return $result;
    }

    // Get the last order id (using MAX)
    public function getLastOrderId()
    {
        $stmt = $this->db->prepare('SELECT MAX(id) FROM orders');
        $stmt->execute();
        $id = $stmt->fetchColumn();
        return $id;
    }

    // Check the ticket status
    public function checkTicket($used)
    {
        if($used === "no") {
            echo "the ticket has not been used.";
        } else {
            echo "has already been used. Please, buy a new one.";
        }
    }

    // Update the ticket status
    public function updateTicketStatus($id_item)
    {
        $stmt = $this->db->prepare('UPDATE orders_items SET used = \'yes\' WHERE id = :id');
        $stmt->bindValue(':id',$id_item,PDO::PARAM_INT);
        $stmt->execute();
        echo "Thank you for buying from us!";
    }
}
?>
