<?php
   require_once('classes/ticket_class.php');
   require_once('classes/database_class.php');
   require_once('classes/order_class.php');
   require_once('classes/convert.php') ;

  $id = new Order();
  $order_id = $id->getLastOrderId();
?>

<?php include "includes/header.php"; ?>

<div class="container">
  <br>
  <h2>Thank you for your order number: <?php echo $order_id; ?></h2>
  <br>

<!-- Shoppingcart on the top -->
  <div id="cart" style=padding-left:850px onclick="showCart('shopping_cart');">
    <i class="fa fa-shopping-cart fa-2x" aria-hidden="true"></i>
    <span id="itemCount"></span>
  </div>

  <a href="index.php" class="btn btn-primary" onclick="deleteCookie();" role="button">Go to Admin</a>
  <br>
  <br>
  <a href="checkin.php" class="btn btn-primary" onclick="deleteCookie();" role="button">Go to Check In</a>
  <br>
</div>

