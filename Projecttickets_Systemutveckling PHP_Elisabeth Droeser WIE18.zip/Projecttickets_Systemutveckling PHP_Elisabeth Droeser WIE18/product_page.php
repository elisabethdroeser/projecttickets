<?php
  require_once('classes/ticket_class.php');
  require_once('classes/database_class.php');
  require_once('classes/order_class.php');
  require_once('classes/convert.php') ;

  $ticket = new Ticket();
  $rows = $ticket->getTickets();
?>

<!-- Cookie  -->
<?php
  if (isset($_COOKIE['cart'])) {
    $cart_array = json_decode(stripslashes($_COOKIE['cart']),true);
  }
?>

<!-- Create an order -->
<?php
  if (isset($_POST['create_order']))
  {
    $user_name = filter_input(INPUT_POST, 'user_name', FILTER_SANITIZE_MAGIC_QUOTES);
    $user_email = filter_input(INPUT_POST, 'user_email', FILTER_SANITIZE_EMAIL);

    foreach ($cart_array as $key => $value)
    {
        $ticket_id = (int)$value['id'];
        $my_array [] = $ticket_id;
    }

    var_dump($my_array);

    $stmt = new Order();
    $result = $stmt->createOrder($user_name, $user_email, $my_array);
  }
?>

<?php include "includes/header.php";?>

<div id="top" class="container">

<!-- Shoppingcart icon  -->
  <a href="#top">
    <div id="cart-red" style="padding-left:850px;" onclick="showCart('shopping_cart');">
      <i class="fa fa-shopping-cart fa-2x" aria-hidden="true"></i>
      <span id="itemCount">0</span>
    </div>
  </a>

<!-- Shoppingcart -->
  <div id="shopping_cart">
    <section class="container content-section">
      <h2 class="section-header">Shopping cart</h2>
      <div class="cart-row">
        <span class="cart-item cart-header cart-column">Title</span>
        <span class="cart-price cart-header cart-column">Price</span>
        <span class="cart-quantity cart-header cart-column">Quantity</span>
      </div>
      <div class="cart-items">
      </div>
      <div class="cart-total">
        <strong class="cart-total-title">Total</strong>
        <span class="cart-total-price">SEK 0</span>
      </div>
      <button class="btn btn-primary btn-purchase" type="button" onclick="formToggle('my_form');">CheckOut</button>
    </section>

  <!-- Check out -->
    <form id="my_form" method="post" style="padding: 0 0 20px 0;"><br>
      <div class="input-group mb-3">
        <input type="text" name="user_name" placeholder="Your name" required><br>
        <div class="input-group-prepend">
          <span class="input-group-text">Example</span>
        </div>
      </div>
      <div class="input-group mb-3">
        <input type="email" name="user_email" placeholder="Your email" required>
        <div class="input-group-append">
          <span class="input-group-text">@example.com</span>
        </div>
      </div>
      <button class="btn btn-success" name="create_order" value="Submit">Submit</button>
    </form>
  </div>

  <!-- Product list -->
  <section class="container content-section">
   <h2 class="section-header">Tickets</h2>
    <div class="shop-items">
    <?php foreach ($rows as $row) : ?>
      <div class="shop-item" style="padding: 20px 0;">
        <span class="shop-item-title"><?php echo escape($row["name"]); ?></span>
        <span class="shop-item-description"><?php echo escape($row["description"]); ?></span>
        <br>
        <br>
        <img class="shop-item-image" height=350 width=250 src="<?php echo escape($row["image"]); ?>">
        <div class="shop-item-details">
          <span class="shop-item-price"><?php echo "SEK " . escape($row["price"]); ?></span>
          <input class="shop-item-id" type="hidden" name="id" value="<?php echo escape($row['id'])?>">
          <input class="shop-item-qty" type="hidden" name="qty" value="1">
          <br>
          <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
          <br>
          <br>
        </div>
      </div>
    <?php endforeach; ?>
    </div>
  </section>

  <a href="index.php" class="btn btn-primary" role="button">Go to Admin page (Tickets)</a><br>
  <br>
  <a href="checkin.php" class="btn btn-primary" role="button">Check-in at the event</a><br>
  <br>
  <a href="confirm_order.php" class="btn btn-primary" role="button">Confirm your order</a><br>

</div>



