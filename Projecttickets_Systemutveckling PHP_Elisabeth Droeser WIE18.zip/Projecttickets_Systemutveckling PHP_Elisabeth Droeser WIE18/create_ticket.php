<?php
  require_once('classes/ticket_class.php');
  require_once('classes/database_class.php');
  require_once('classes/order_class.php');
  require_once('classes/convert.php') ;

  if (isset($_POST['add'])) {
  $column = [
      ':name' =>  filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING),
      ':description' =>  filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING),
      ':price' =>  filter_input(INPUT_POST, 'price', FILTER_SANITIZE_NUMBER_FLOAT),
      ':image' =>  filter_input(INPUT_POST, 'image', FILTER_SANITIZE_STRING)
  ];

  $addTicket = new Ticket();
  $addTicket->createTicket($column);
}
?>

<?php include 'includes/header.php'; ?>

<div class="container">
  <h3>Create a new ticket</h3>
  <?php if (isset($_POST['add']) && $addTicket) {
      echo $_POST['name']; ?> successfully added.<br>
  <?php } ?><br>

  <div id="new_ticket">
    <form method="POST">
      <label for="name_ticket">Name</label>
      <input type="text" class="form-control" name="name" required>
      <label for="image">Description</label>
      <input type="text" class="form-control" name="description"><br>
      <label for="price">Price</label>
      <input type="number" step="any" min="1" class="form-control" name="price" required>
      <br>
      <label for="image">Image</label>
      <p>By adding an image you need to write img/ at first</p>
      <input type="text" class="form-control" name="image" required><br>
      <button type="submit" class="btn btn-success" name="add"> Add new ticket</button>
    </form>
    <br>
  </div>

</div>