-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Aug 28, 2020 at 12:22 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `projecttickets`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `customer_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_name`, `customer_email`) VALUES
(1, 'Elisabeth Droeser', 'droeser.lisa@gmail.com'),
(2, 'Lisa', 'droeser.lisa@gmail.com'),
(3, 'Lisa', 'droeser.lisa@gmail.com'),
(4, 'Erik', 'erik.uppenberg@lr.se'),
(5, 'Elisbeth', 'droeser.lisa@gmail.com'),
(6, 'Anna', 'christell@gmail.com'),
(7, 'Anna', 'christell@gmail.com'),
(8, 'bettan', 'bettan@gmail.com'),
(9, 'hejhopp', 'hejhopp@gmail.com'),
(10, 'Lisa Uppenberg', 'uppenberg@gmail.com'),
(11, 'stina', 'info@ekstrom.com'),
(12, 'stina', 'info@ekstrom.com'),
(13, 'anna', 'anna@christell.com'),
(14, 'test', 'test@gmail.com'),
(15, 'peter', 'peter.pettersson@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `orders_items`
--

CREATE TABLE `orders_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `used` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders_items`
--

INSERT INTO `orders_items` (`id`, `order_id`, `ticket_id`, `used`) VALUES
(1, 1, 5, 'no'),
(2, 2, 2, 'no'),
(3, 15, 14, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `name`, `description`, `price`, `image`) VALUES
(5, 'Cosmopolite', 'Bröllopsdans', 150, 'img/cosmopolite.jpg'),
(8, 'Vigsel', 'Drop-in-vigsel på Tingvallen, Skansen', 100, 'img/tingvallen.jpg'),
(14, 'Mingle', 'Mat och dryck på Fleminggatan 54', 200, 'img/rosevin.jpg'),
(15, 'Skansen', 'Besök på Skansen, Djurgården', 200, 'img/flowers.jpg'),
(16, 'Bröllopstårta', 'Tårtan skärs upp', 250, 'img/weddingcake.jpg'),
(17, 'Nattamat', 'Some bites to eat after the party', 400, 'img/vickning.jpeg'),
(18, 'Skansen skål', 'En exklusiv champagne skål på Skansen', 800, 'img/champagne.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_items`
--
ALTER TABLE `orders_items`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id_idx` (`order_id`) USING BTREE,
  ADD KEY `id_idx1` (`ticket_id`) USING BTREE;

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `orders_items`
--
ALTER TABLE `orders_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders_items`
--
ALTER TABLE `orders_items`
  ADD CONSTRAINT `id` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE NO ACTION;