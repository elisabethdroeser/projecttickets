<?php
  require_once('classes/ticket_class.php');
  require_once('classes/database_class.php');
  require_once('classes/order_class.php');
  require_once('classes/convert.php') ;

  if (isset($_GET['id']))
  {
  $id = $_GET['id'];
  $ticket = new Ticket();
  $result = $ticket->selectTicket($id);
}
?>

<?php include 'includes/header.php'; ?>

<div class="container">
  <h3>Update a ticket</h3>
  <form method="POST" action='' >
    <input type='hidden' name='id' value='<?php echo escape($result['id']);?>'>
    <lable for="name">Ticket Name</lable>
    <input type="text" class="form-control" name="name" value="<?php echo escape($result['name']); ?>" required>
    <lable for="image">Description</lable>
    <input type="text" class="form-control" name="description" value="<?php echo escape($result['description']); ?>"><br>
    <lable for="price">Price</lable>
    <input type="number" class="form-control" name="price" value="<?php echo escape($result['price']); ?>" required>
    <lable for="image">Image</lable>
    <input type="text" class="form-control" name="image" value="<?php echo escape($result['image']); ?>" required><br>
    <button type="submit" class="btn btn-success" name="update" onclick="return confirmIt()">Update ticket</button>
  </form>
  <br>
</div>

<?php

if(isset($_POST['update']))
{
  $column = [
    ':name' =>  filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING),
    ':description' =>  filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING),
    ':price' =>  filter_input(INPUT_POST, 'price', FILTER_SANITIZE_NUMBER_INT),
    ':image' =>  filter_input(INPUT_POST, 'image', FILTER_SANITIZE_STRING)
  ];

  $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
  echo $id;

  $editTicket = new Ticket();
  $editTicket->updateTicket($column, $id);
}
?>