<?php
  require_once('classes/database_class.php');
  require_once('classes/order_class.php');
  require_once('classes/convert.php');

  $id = isset($_POST['id']) ? $_POST['id'] : '';
  $order = new Order();
  $rows = $order->selectOrder($id);
?>

<?php include "includes/header.php"; ?>

<div class="container">

  <!-- Show if the ticket is valid  -->
  <?php
    if (isset($_POST['submit'])) {
      if($rows) { ?>
        <?php foreach ($rows as $row) : ?>
          <table>
            <tr>
              <td><?php //echo escape($row['id']); ?></td>
              <td><?php //echo escape($row['name']); ?></td>
              <td><?php //echo escape($row['customer_name']); ?></td>
              <td><?php //echo escape($row['used']); ?></td>
            </tr>
          </table>
          <br>
        <?php endforeach; ?>

      <!-- Validation:-->
      <p>Hi <strong><?php echo escape($row['customer_name']); ?></strong> your ticket(s): <br>
        <div class="check_ticket">
          <ol><?php foreach ($rows as $row) : ?>
            <li><strong><?php echo escape($row['name']); ?></strong>
            <?php $order->checkTicket($row['used']); ?></li><br>
            <?php endforeach; ?></p></ol>
        </div>
        <?php } else { ?><br>
        <blockquote>No results found for <?php echo escape($_POST['id']); ?>.</blockquote>
  <?php }
}?>

  <!-- Select the order -->
  <form method="post">
    <label for="id">Enter your ticket number</label>
    <input type="text" id="id" name="id"><br><br>
    <input class="btn btn-success" type="submit" name="submit" value="View Results"><br>
  </form>

  <a href="index.php" class="btn btn-primary" role="button">Go to Admin page (Tickets)</a><br>
  <a href="product_page.php" class="btn btn-primary" role="button">Go to shop</a><br>

  <!-- Confirm the ticket -->
  <?php include_once('confirm_ticket.php'); ?>

</div>

