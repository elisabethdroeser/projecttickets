<?php
 	require_once('classes/ticket_class.php');
 	require_once('classes/database_class.php');
 	require_once('classes/order_class.php');
 	require_once('classes/convert.php');

	$ticket = new Ticket();

	if(isset($_GET['delete'])) {
		$id = $_GET['delete'];
		$ticket->deleteticket($id);
	}
?>

<?php include "includes/header.php"; ?>

<br>
<div class="container">
	<div class="search">
		<form id="my_form" method="post" class="example">
			<input type="text" style="padding: 10px;" name="search" placeholder="Search ...">
			<button type="submit" style="padding: 10px;" name="action"><i class="fa fa-search"></i></button>
		</form>
    <br>
		<?php
			$tickets = new Ticket();
			$list_tickets;

			if (isset($_POST['action']))
			{
				global $list_tickets, $tickets;

				$search = filter_input(INPUT_POST, 'search', FILTER_SANITIZE_MAGIC_QUOTES);
				echo "You searched for <strong>$search</strong><br>";
				$list_tickets = $tickets->searchTicket($search);
			} else {
				global $list_tickets, $tickets;
				$list_tickets = $tickets->getTickets();
			}
		?>
	</div>

  <br>
	<h2>List with all tickets</h2>
	<br>
	<a href="create_ticket.php" class="btn btn-primary">Create a ticket</a>
	<br>
	<br>
	<table class="table">
		<thead>
			<tr>
				<th>#</th>
				<th>Id</th>
				<th>Name</th>
        <th>Description</th>
				<th>Price</th>
				<th>Image</th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			<?php
			$rows = $list_tickets;
			$i = 1;
			foreach ($rows as $row) { ?>
				<tr>
					<th scope="row"><?php echo escape($i) ?></th>
					<td><?php echo escape($row['id']); ?></td>
					<td><?php echo escape($row['name']); ?></td>
          <td><?php echo escape($row['description']); ?></td>
					<td><?php echo escape($row['price']); ?></td>
					<td><?php echo escape($row['image']); ?></td>
					<td>
						<a class="btn btn-sm btn-primary" href="update_ticket.php?id=<?php echo escape($row['id']); ?>">Update</a>
						<a class="btn btn-sm btn-danger" style="padding: 0.67em;" href="index.php?delete=<?php echo escape($row['id']); ?>"onclick="return confirmDelete()">Delete</a>
					</td>
				</tr>
			<?php
			$i++;
			 }
			?>
		</tbody>
	</table>

	<a href="product_page.php" class="btn btn-primary">To shop tickets</a><br>

</div>


